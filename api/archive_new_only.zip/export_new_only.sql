DELETE FROM m_kendaraan WHERE cabang >= '';
INSERT INTO m_kendaraan (id, cabang, nomorPolisi, noMesin, noRangka) VALUES
