DELETE FROM m_kendaraan WHERE created_at >= '2023-06-22 07:01:03';
INSERT INTO m_kendaraan (id, nomorPolisi, noMesin, noRangka) VALUES
